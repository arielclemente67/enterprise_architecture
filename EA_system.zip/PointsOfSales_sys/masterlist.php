<?php 

$servername = "localhost";
$database = "enterprise_architecture";  // fill up the blank with the name of your database
$username = "root";
$password = ""; 

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
  //die("Connected Successfully to your database");
if (!$conn) {
  //die("Connection failed: " . mysqli_connect_error());
}
$sql1 = " SELECT * from sales order by sales_date DESC, emp_num ASC ";
$result = mysqli_query($conn, $sql1) ; 


?>
<h2>Sales Masterlist</h2>

<table width="100%" border="1"> 
    <tr>
        <td>Product #</td>
        <td>Product Name</td>
        <td>Product Brand</td>
        <td>Quantity</td>
        <td>Unit Price</td>
        <td>Sub Total</td>
    </tr>

    <?php 
        while($row = mysqli_fetch_assoc($result) ) {
	$prodnumber = $row['productnumber'];
	$productname = $row['productname'];
	     
    ?>

    <tr>
        <td><?php echo $prodnumber; ?></td>
        <td> <?php echo $productname; ?></td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
   
   <?php  } ?>
</table> 
<h1>KSWEB - P275</h1>