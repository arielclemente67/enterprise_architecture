<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "enterprise_architecture";

$conn = mysqli_connect($servername,$username, $password, $databasename); 
if(!$conn) {
   // die("Connection failed.");
} else {
  //  die("Connection successful");
}

if(isset($_POST['btnSubmit'])) {
  $prod_number =$_POST['productnumber'] ;
  $qty = $_POST['qty'] ;

  $sql1 = "SELECT * from products where productnumber = '$prod_number' "; 
  $result = mysqli_query($conn, $sql1) ;
  $row = mysqli_fetch_assoc($result); 
  
  $pnumber = $row['productnumber'];
  $pname = $row['productname'];
  $unitprice = $row['price'];
  $subtotal = $qty * $unitprice;

  $sql2 = "INSERT into cart (productnumber,productname,price,quantity,subtotal) " 
     . " values ('$pnumber','$pname','$unitprice','$qty','$subtotal') ";
   mysqli_query($conn, $sql2); 
   
   $sql3 = "SELECT * from cart";
   $result3 = mysqli_query($conn, $sql3) ;
   
}
?>

<form name="myForm" method="POST">
 <input type="text" name="qty" id="qty" size="2" value="1">
 <input type="text" name="productnumber" id="productnumber" size="6">
 <input type="submit" name="btnSubmit" id="btnSubmit" value="Buy">
</form>

<table width="500" border="1">
 <tr>
  <td>Items</td>
  <td>Sub Total</td>
</tr>
 <?php while($row3 = mysqli_fetch_assoc( $result3)) {
     $p_qty = $row3['quantity'];
     $p_number = $row3['productnumber'];
     $p_name = $row3['productname'];
     $unit_price = $row3['price'];
     $sub_total = $row3['subtotal'];
 
 ?>
 <tr>
  <td><?php echo $p_qty; ?> x <?php echo $p_number; ?>&nbsp;-<?php echo $p_name; ?>&nbsp;@<?php echo $unit_price; ?>&nbsp;-</td>
  <td><?php echo $sub_total; ?></td>
</tr>

<?php } ?>
</table>



