<?php
$con  = mysqli_connect("localhost","root","","enterprise_architecture");

if (!$con) {
     # code...
   echo "Problem in database connection! Contact administrator!" . mysqli_error();
 }  
 
        $salestotal = 0;
        
        $sql2 ="SELECT DISTINCT productnumber, productname, subtotal FROM sales ORDER BY productnumber DESC";
        $result2 = mysqli_query($con, $sql2);
        $result5= mysqli_query($con, "DELETE from sales_chart");

        while ($row2 = mysqli_fetch_assoc($result2)) {
        $productnumber1  = $row2['productnumber'];
        $productname  = $row2['productname'];
        
            $sql1 ="SELECT * FROM sales where productnumber = '$productnumber1' ";
            $result1 = mysqli_query($con, $sql1);
            $row1 = mysqli_fetch_assoc($result1);
            $subtotal1 = $row1['subtotal'];
            $salestotal = $salestotal + $subtotal1;
            
            $sql3 = "INSERT into sales_chart (productnumber, productname, salestotal) "
            . " values ('$productnumber1','$productname', '$salestotal') ";
            $result3 = mysqli_query($con, $sql3);

        }        
        
         $sql ="SELECT * FROM sales_chart";
         $result = mysqli_query($con,$sql);
         $chart_data="";
         while ($row = mysqli_fetch_assoc($result)) {
            $productnumber[]  = $row['productname'];
            $sales[] = $row['salestotal'];
        }
 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Data Analytics</title>
    </head>
    <body>
        <center>
        <h2 class="page-header" >Data Analytics Reports </h2>
        <div style="width:50%; height:18%;text-align:center">
            <div>Product Number </div>
            <canvas  id="chartjs_bar"></canvas>
        </div>    
    </body>
  <script src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script type="text/javascript">
      var ctx = document.getElementById("chartjs_bar").getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels:<?php echo json_encode($productnumber); ?>,
                        datasets: [{
                            backgroundColor: [
                               "#5969ff",
                                "#ff407b",
                                "#25d5f2",
                                "#ffc750",
                                "#2ec551",
                                "#7040fa",
                                "#ff004e"
                            ],
                            data:<?php echo json_encode($sales); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: true,
                        position: 'bottom',
 
                        labels: {
                            fontColor: '#71748d',
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
 
                   
                }
                });
    </script>
</html>