<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sales Receipt </title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #FFFFFF;
}
.style136 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style137 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }
.style138 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.style139 {font-size: 12px}
.style141 {font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold; }

-->
</style>
</head>

<?php 
@session_start();
include("webconnect.php");

$datep=date('M d, Y H:i:s');

/*
ini_set("post_max_size","128M");
ini_set("session.gc_maxlifetime","10800"); 
ini_set("upload_max_filesize", "200M");
*/

$sql1 = " SELECT * from cart order by productname ASC, productbrand ASC ";
$result = mysqli_query($conn, $sql1) ; 

// //-- SEARCH by individual
if(isset($_POST['btnSearch2'])) 
{
   $criteria2 = $_POST['criteria'];
   $variable2 = $_POST['textsearch2'];

  if($variable2 =="") {
  $sql25 =" select * from products ORDER by productname ASC ";
  $result = mysqli_query($conn, $sql25);
//$row2 = mysqli_fetch_assoc($result);

} else {

   $sql27 = "select * from products where productnumber='$variable2' ORDER by productname ASC " ;
   $result = mysqli_query($conn, $sql27);
   $row1 = mysqli_fetch_assoc($result);
   $productNumber = $row1['productnumber'];
   $productName = $row1['productname'];
   $productBrand = $row1['productbrand'];
   $unitprice = $row1['price'];
   $subtotal = $criteria2 * $unitprice;  //calculate the quantity * unitprice

 //insert item to Temporary sales cart
   $sql26 = "INSERT into cart (quantity,productnumber,productname,productbrand,price,subtotal,emp_num,sales_date,sales_invoice) "
      . " values ('$criteria2','$productNumber','$productName', '$productBrand','$unitprice', '$subtotal', '#','$datep', '#') " ;
   mysqli_query($conn, $sql26);
 
   $sql28 = "select * from cart order by id " ;
   $result = mysqli_query($conn, $sql28);
 //  $row23 = mysqli_fetch_assoc($result3);
  }
  //finalize the sales by saving the entire transactions to the SALES table and clean the CART
  if(isset($_POST['payment'])) {
    $sql29 = "INSERT into sales values (select * from cart) " ;
    mysqli_query($conn, $sql29);

    // empty the CART table
    $sql30 = "DELETE * from cart" ;
    mysqli_query($conn, $sql30);
  }
}
?>

<body>
<?php include("mainmenu.php"); ?>
<center><br>
 <h2>Cash Register</h2>
  <table width="97%" border="1" cellpadding="1" cellspacing="1" bordercolor="rgb(255, 255, 255)">
  <tr>
    <td width="76%" height="33" colspan="2" class="style13">
    <form id="form4" name="form4" method="post">
      <span class="style92">Qty:</span>
       <input type="text" name="criteria" id="criteria" size="2" value="1">
       <input name="textsearch2" type="text" id="textsearch2" size="9" />
      <input name="btnSearch2" type="submit" id="btnSearch2" value="Go" />
   </form> </td>
   <td width="20%" colspan="3" align="center" class="style137">Unit Price:&nbsp;&nbsp;<strong><?php echo @$unitprice; ?></strong></td>
    </tr>
  <tr>
    <td width="10%" height="24" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product No.</strong></td>
    <td width="14%" align="center" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Quantity</strong></td>
    <td width="21%" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product Name </strong></td>
    <td width="8%" align="center" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Sub. Total</strong></td>
    <td width="3%" align="center" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>**</strong></td>
    </tr>
 <?php 
  $subtotals = 0;
 	while($row4 = mysqli_fetch_assoc($result)) {
	$qty = $row4['quantity']; 
  $totals = $row4['subtotal']; 
	$subtotals = $subtotals + $totals; 
	 			// --- alternating row colors
			if(@$color == "#DDE0EE") {
		     	@$color = "#F4F4F4";
    			} else {
      			@$color = "#DDE0EE";
    		}			

 ?>
  <tr>
    <td height="26" bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138">Prod. No.<?php echo $row4['productnumber']; ?></span></td>
    <td height="26" align="center" bgcolor="<?php echo $color; ?>" class="style127 style138 style139" ><?php echo $row4['quantity']; ?></td>
    <td bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php echo $row4['productname']; ?></span></td>
    <td align="right" bgcolor="<?php echo $color; ?>" class="style127 style136 style138" ><?php echo $row4['price']; ?>&nbsp;</td>
    <td width="3%" align="center" bgcolor="#E0E8F1" class="style139 style136 style138"><strong><a href="delete_item_from_cart.php?id=<?php echo $row4['id']; ?>" onclick="return confirm('Are your sure you want to delete this item?')"><img src="001_49.png" width="20" height="20d" border="0" /></a></strong></td>
    </tr>
 <?php } ?> 
   <tr>
    <td align="left" colspan="2" height="40">
    <form id="form3" name="form3" method="post">
      <span class="style92">Amt. Paid:</span>
       <input type="number" name="payment" id="payment" size="8" value="0">
      <input name="payment" type="submit" id="payment" value="Pay" />
   </form></td> 
   <td colspan="3" align="right" class="style137">Sales Sub Totals:&nbsp;<strong><?php echo $subtotals; ?></strong>&nbsp;&nbsp;</td></tr>
</table>
</center>
<br />
<center><span class="style49 style138"><a href="index.php">MSTIP</a>-Home </span>
</center>
</body>

</html>

