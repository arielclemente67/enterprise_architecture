<?php 

$servername = "localhost";
$username = "root";
$password = ""; 
$database = "enterprise_architecture";  // fill up the blank with the name of your database

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
  
if (!$conn) {
  //die("Connection failed: " . mysqli_connect_error());
} else {
  //die("Connected Successfully to your database");
}

?>
