<?php 
$server = "localhost";
$user = "root";
$password = "";
$database  = "enterprise_architecture";

$conn= mysqli_connect($server, $user, $password, $database) ;

if(!$conn) { 
 //die('Failed to connect');
} else {
 //die('Connected successfully');
}  

if(isset($_POST['go'])) {
$qty = $_POST['qty'];
$p_number = $_POST['prod_num'];

$sql = "SELECT * from products where productnumber = '$p_number'";
$result = mysqli_query($conn, $sql); 
$row = mysqli_fetch_assoc($result);
$prod_number = $row['productnumber'] ;
$prod_name = $row['productname'];
$unit_price = $row['price'];
$sub_total = $unit_price * $qty;
}

?>
<table width ="500" border="1">
 <tr>
   <td>
    <form name="form1" method="POST">
     Qty<input type="text" size="2" name="qty" id="qty" value="1">
     <input type="text" size="4" name="prod_num" id="prod_num"> 
     <input type="submit" name="go" value="Go"> 
    </form>

   </td>
   <td>Sub Total</td>
 </tr>
  
 <tr>
  <td><?php echo $qty; ?>&nbsp;x&nbsp;<?php echo $prod_number; ?>&nbsp;<?php echo $prod_name; ?>&nbsp;@&nbsp;<?php echo $unit_price; ?></td>
  <td><?php echo $sub_total; ?></td>
  
 </tr>

</table>