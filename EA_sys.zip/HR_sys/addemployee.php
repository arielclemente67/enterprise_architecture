<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee Info</title>
   <link rel="stylesheet" href="loginstyle.css">

  </head>
<?php
include("webconnect.php");

if(isset($_POST['Submit'])) 
{

$empnumber = $_POST['employeenumber'];
$firstname = $_POST['firstname'];
$mi= $_POST['mi'];
$lname= $_POST['lastname'];

//$lastname =  
//$position =  


$sql2 = " SELECT * from employees WHERE employeenumber = '$empnumber' AND lastname = '$lastname' AND firstname = '$firstname' AND mi = '$mi' ";
$result = mysqli_query($conn, $sql2); 		
//$row = mysqli_fetch_assoc($result);
$count = mysqli_num_rows($result);

if($count==0) {

	$sql = "INSERT INTO employees (emp_num, fname, mname, lname) VALUES('$empnumber','$firstname','$mi','$lname'  )";
	mysqli_query($conn, $sql);
	?>
	<SCRIPT Language=Javascript>
	<!--
	alert("Employee details has been successfully added!");
	// End -->
	</SCRIPT>

	<SCRIPT Language=Javascript>
	<!--
      location.href="index.php";
	// End -->
	</SCRIPT>
 <?php
} else {
?>

<SCRIPT Language=Javascript>
<!--
	alert("Record Already exists. Please try again!");
// End -->
</SCRIPT>

<SCRIPT Language=Javascript>
<!--
 location.href="addemployee.php";
// End -->

</SCRIPT>

<?php
  }
 }


?>
<?php include("mainmenu.php") ; ?>
  <body>
    <div class="container">
      <div class="wrapper">
        <div class="title"><span>Add Employee Info.</span></div>
		<form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return validateMe(this.textfield.value);">
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="employeenumber"  placeholder="Employee Number" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="firstname"  placeholder="First Name" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="mi"  placeholder="Middle Inistial" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="lastname"  placeholder="Last Name" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="position"  placeholder="Position" required>
          </div>

          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="gender"  placeholder="Gender" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="address"  placeholder="Address" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" name="emp_status"  placeholder="Employee Status" required>
          </div>

          <div class="row">
            <input type="submit" value="Submit" name="Submit">
          </div>
        </form>
        <center>
         <div class="signup-link"><a href="time_logs.php">Time Logs</a> | &nbsp;<a href="index.php">Home</a></div>
     </div>
    </div>|

  </body>

</body>
</html>

