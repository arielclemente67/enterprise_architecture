<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products Details</title>
    <style>
form {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

label {display: block;}

input[type=text], select {
  width: 100%;
  padding: 12px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
</style>
  </head>
<?php
include("webconnect.php");

if(isset($_POST['Submit'])) 
{

$productnumber = $_POST['productnumber'];
$productname = $_POST['productname'];
$productbrand= $_POST['productbrand'];
$price= $_POST['price']; 


$sql2 = " SELECT * from products WHERE productnumber = '$productnumber' AND productname = '$productname'  ";
$result = mysqli_query($conn, $sql2); 		
//$row = mysqli_fetch_assoc($result);
$count = mysqli_num_rows($result);

if($count==0) {

	$sql = "INSERT INTO products (productnumber, productname, productbrand, price) VALUES('$productnumber','$productname','$productbrand','$price'  )";
	mysqli_query($conn, $sql);
	?>
	<SCRIPT Language=Javascript>
	<!--
	alert("Product details has been successfully added!");
	// End -->
	</SCRIPT>

	<SCRIPT Language=Javascript>
	<!--
      location.href="index.php";
	// End -->
	</SCRIPT>
 <?php
} else {
?>

<SCRIPT Language=Javascript>
<!--
	alert("Record Already exists. Please try again!");
// End -->
</SCRIPT>

<SCRIPT Language=Javascript>
<!--
 location.href="addproduct.php";
// End -->

</SCRIPT>

<?php
  }
 }


?>
<?php include("mainmenu.php") ; ?>
  <body>
    <div class="container">
      <form name="myform" method="POST">
      <label for="header"><h2>Add Product Details</h2></label>
        <label for="productnumber">Product Number</label>
        <input type="text" id="productnumber" name="productnumber" placeholder="Product Number">

        <label for="productname">Product Name</label>
        <input type="text" id="productname" name="productname" placeholder="Product Name">

        <label for="productbrand">Product Brand</label>
        <input type="text" id="productbrand" name="productbrand" placeholder="Product Brand">

        <label for="price">Product Price</label>
        <input type="text" id="productprice" name="productprice" placeholder="Price">

        <label for="quantity">Quantity</label>
        <input type="text" id="quantity" name="quantity" placeholder="Quntity">
        
        <label for="productstatus">Product Status</label>
        <input type="text" id="productstatus" name="productstatus" placeholder="Product Status">
        
        <input type="submit" value="Submit">
      </form>
        <center>
         <div class="signup-link"><a href="time_logs.php">Time Logs</a> | &nbsp;<a href="index.php">Home</a></div>
     </div>
 
  </body>

</body>
</html>

