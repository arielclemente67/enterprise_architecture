<?php 
include("webconnect.php");

$id = $_REQUEST['empid'];
$sql = "DELETE from products where id = '$id' "; 
$result = mysqli_query($conn, $sql);
?>

<script>
    <!--
    alert("Record has been successfully deleted");
    // End -->
</script>
<script>
 <!--
  location.href="products_masterlist.php";
  // End -->
</script>