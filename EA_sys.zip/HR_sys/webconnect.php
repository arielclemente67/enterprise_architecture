<?php 

$servername = "localhost";
$database = "enterprise_architecture";  // fill up the blank with the name of your database
$username = "root";
$password = ""; 

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
  //die("Connected Successfully to your database");
if (!$conn) {
  //die("Connection failed: " . mysqli_connect_error());
}

?>
