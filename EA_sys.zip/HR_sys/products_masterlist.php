<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Products Masterlist</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #FFFFFF;
}
.style136 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style138 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; }
.style139 {font-size: 14px}
.style141 {font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold; }

-->
</style>
</head>

<?php 
@session_start();
include("webconnect.php");

$datep=date('M d, Y H:i:s');

/*
ini_set("post_max_size","128M");
ini_set("session.gc_maxlifetime","10800"); 
ini_set("upload_max_filesize", "200M");
*/

$sql1 = " SELECT * from products order by productname ASC, productbrand ASC ";
$result = mysqli_query($conn, $sql1) ; 

// //-- SEARCH by individual
if(isset($_POST['btnSearch2'])) 
{
   $criteria2 = $_POST['criteria'];
   $variable2 = $_POST['textsearch2'];

  if($variable2 =="") {
  $sql25 =" select * from products ORDER by productname ASC ";
  $result = mysqli_query($conn, $sql25);
//$row2 = mysqli_fetch_assoc($result);

} else {

 //if($criteria2 == "description") {
   $sql27 = "select * from products where $criteria2 LIKE '%%$variable2%%' ORDER by productname ASC " ;
   $result = mysqli_query($conn, $sql27);
 //$row2 = mysqli_fetch_assoc($result);
 }
}

// //- VIEW ALL
// //-- SEARCH by individual
if(isset($_POST['btnSearch22'])) 
{
 //if($criteria2 == "description") {
   $sql28 = "select * from products ORDER by productname ASC, productbrand ASC " ;
   $result = mysqli_query($conn, $sql28);
 //$row2 = mysqli_fetch_assoc($result);
}


?>

<body>
<?php include("mainmenu.php"); ?>
<center>
  <table width="98%" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF">
  <tr>
    <td height="33" colspan="7" class="style13"><form id="form4" name="form4" method="post">
      <span class="style92">Search by:</span>
      <select name="criteria" id="criteria">
        <option selected="selected">Select</option
        >
        <option value="productnumber">Product Number</option>
        <option value="productname">Produc Name</option>
        <option value="productbrand">Product Brand</option>
      </select>
      <input name="textsearch2" type="text" id="textsearch2" size="28" />
      <input name="btnSearch2" type="submit" id="btnSearch2" value="  Go  " />
      <input name="btnSearch22" type="submit" id="btnSearch22" value="  View All  " />
    </form>      </td>
    <td colspan="3" class="style13"><span class="style141">Products Masterlist &nbsp;&nbsp;<a href="productsmasterlist.php"> View</a> </span></td>
    </tr>
  <tr>
    <td width="6%" height="24" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product Num </strong></td>
    <td width="8%" align="center" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Quantity</strong></td>
    <td width="10%" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product Name </strong></td>
    <td width="11%" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product Brand </strong></td>
    <td width="9%" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>&nbsp;Product Price</strong></td>
    <td colspan="2" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Photo</strong></td>
    <td width="20%" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>Product Status </strong><strong> </strong></td>
    <td width="5%" align="center" bgcolor="#E0E8F1" class="style139 style136 style13"><strong>*</strong></td>
    </tr>
 <?php 
 	while($row4 = mysqli_fetch_assoc($result)) {
	
	
	 			// --- alternating row colors
			if(@$color == "#DDE0EE") {
		     	@$color = "#F4F4F4";
    			} else {
      			@$color = "#DDE0EE";
    		}			

 ?>
  <tr>
    <td height="26" bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php echo $row4['productnumber']; ?></span></td>
    <td height="26" align="center" bgcolor="<?php echo $color; ?>" class="style127 style138 style139" ><?php echo $row4['quantity']; ?></td>
    <td bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php echo $row4['productname']; ?></span></td>
    <td bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php echo $row4['productbrand']; ?></span></td>
    <td align="left" bgcolor="<?php echo $color; ?>" class="style127 style136 style138" >&nbsp;<?php $row4['price']; ?></td>
    <td colspan="2" bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php $row4['photo']; ?></span></td>
    <td bgcolor="<?php echo $color; ?>" class="style127" ><span class="style138"><?php ; ?></span><?php $row4['productstatus']; ?></td>
    <td align="center" bgcolor="<?php echo $color; ?>" class="style127 style136 style138" ><a href="updateproducts.php?email=<?php echo $row4['productnumber']; ?>"><img src="buttons/pclip2.jpg" width="27" height="22" /></a></td>
    </tr>
 <?php } ?> 
</table>
</center>
<br />
<center><span class="style49 style136"><a href="index.php">MSTIP</a>-Home </span>
</center>
</body>

</html>

